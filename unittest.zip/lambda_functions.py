import json
from pymongo import MongoClient
import db_utils
from os import path

class DBConnect:
    db_uri = str(db_utils.ConstantValue)
    ca_cert = path.join(path.dirname(db_utils.__file__), db_utils.CA_CERTIFICATE_FILE)

    def __init__(self):
        """
        Initializer method for database connection
        """
        self.client = self.__connect()

    def __connect(self):
        return MongoClient(self.__db_uri(), ssl=True)

    def __db_uri(self):
        ca_cert = f'/?tlsCAFile={DBConnect.ca_cert}&maxIdleTimeMS=50000'
        return DBConnect.db_uri + ca_cert

def lambda_handler(event,context):
    #TODO implement
    try:
        client = DBConnect().client
        db = client['alexandria_General']
        cm = db["Country_Master"]
        response = cm.find({},{'_id':0})
        ret = []
        for doc in response:
            ret.append(doc)
        client.close()
        return{
            'isError' : False,
            'body' : ret
        }
    except Exception as e:
        return{
            'isError': True,
            'body': 'Error occurred: %s' % (str(e))
        }
